#Rana Musa 1210007
#Donia Alshiakh 1210517
#Haneen Odah 1210716

from socket import *
import os

def send_file(connectionSocket, file_path, content_type):
    with open(file_path, "rb") as file:
        file_data = file.read()
        response = f"HTTP/1.1 200 OK\r\nContent-Type: {content_type}\r\n\r\n".encode() + file_data
        connectionSocket.send(response)



def send_error_404(connectionSocket, addr):
    names_and_ids = "Rana Musa   1210007"
    names_and_ids += "<br>Donia Alshiakh 1210517"
    names_and_ids += "<br>Haneen Odah 1210716"

    error_message = f"""
        <html>
        <head>
            <title>Error 404</title>
        </head>
        <body style="text-align: center;">
            <h1 style="color: black;">HTTP/1.1 404 Not Found</h1>
            <p style="font-size: 16px; color: red; font-weight: bold;">The file is not found</p>
            <b>{names_and_ids}</b><br>
            <b>Client IP:</b> {addr[0]}<br>
            <b>Client Port:</b> {addr[1]}
        </body>
        </html>
    """

    response = f"HTTP/1.1 404 Not Found\r\nContent-Type: text/html\r\n\r\n{error_message}".encode()

    connectionSocket.send(response)






serverPort = 9966
serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(("", serverPort))
serverSocket.listen(1)
print("The server is ready to receive")

while True:
    try:
        connectionSocket, addr = serverSocket.accept()
        sentence = connectionSocket.recv(2048).decode()
        print(addr)
        print(sentence)
        ip = addr[0]
        port = addr[1]

        lines = sentence.split("\r\n")
        request_line = lines[0]
        request_parts = request_line.split()

        if len(request_parts) > 1:
            request_path = request_parts[1]

            if request_path in ['/', '/index.html', '/main_en.html', '/en']:
                send_file(connectionSocket, 'main_en.html', 'text/html')

            elif request_path == '/ar':
                send_file(connectionSocket, 'main_ar.html', 'text/html')

            elif request_path.endswith('.html'):
                send_file(connectionSocket, request_path[1:], 'text/html')

            elif request_path.endswith('.css'):
                send_file(connectionSocket, request_path[1:], 'text/css')

            elif request_path.endswith('.png'):
                send_file(connectionSocket, request_path[1:], 'image/png')

            elif request_path.endswith('.jpg'):
                send_file(connectionSocket, request_path[1:], 'image/jpeg')

            elif request_path == '/cr':
                response = "HTTP/1.1 307 Temporary Redirect\r\nLocation: http://cornell.edu\r\n\r\n".encode()
                connectionSocket.send(response)

            elif request_path == '/so':
                response = "HTTP/1.1 307 Temporary Redirect\r\nLocation: http://stackoverflow.com\r\n\r\n".encode()
                connectionSocket.send(response)

            elif request_path == '/rt':
                response = "HTTP/1.1 307 Temporary Redirect\r\nLocation: https://ritaj.birzeit.edu/register/\r\n\r\n".encode()
                connectionSocket.send(response)

            else:
                send_error_404(connectionSocket, addr)

        connectionSocket.close()

    except Exception as e:
        print("Error:", e)
        connectionSocket.close()
